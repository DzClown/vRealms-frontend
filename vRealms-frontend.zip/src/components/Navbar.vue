<template>
  <v-toolbar flat>
    <v-toolbar-title>Navbar</v-toolbar-title>
  </v-toolbar>
</template>
