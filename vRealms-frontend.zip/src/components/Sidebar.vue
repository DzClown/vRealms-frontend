<template>
  <v-list>
    <v-list-item link :to="{ name: 'Dashboard' }">Dashboard</v-list-item>
    <v-list-item link @click="logout">Logout</v-list-item>
  </v-list>
</template>

<script>
export default {
  methods: {
    logout() {
      localStorage.removeItem('accessToken');
      this.$router.push({ name: 'Login' });
    },
  },
};
</script>
