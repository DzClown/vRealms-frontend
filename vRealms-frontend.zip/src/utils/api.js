// src/utils/api.js
import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
})

function getCookie(name) {
  const cookieString = document.cookie
  const cookies = cookieString ? cookieString.split('; ') : []
  for (let i = 0; i < cookies.length; i++) {
    const cookie = cookies[i]
    const parts = cookie.split('=')
    const cookieName = decodeURIComponent(parts[0])
    if (cookieName === name) {
      return decodeURIComponent(parts.slice(1).join('='))
    }
  }

  return null
}

api.interceptors.request.use(
  config => {
    if (!config) {
      config = {}
    }

    const accessToken = getCookie('vrealms-dash-admin-accessToken')

    if (accessToken && accessToken !== 'null') {
      config.headers = config.headers || {}
      config.headers.Authorization = `Bearer ${accessToken}`
    }

    // Pastikan pengaturan withCredentials tetap false
    config.withCredentials = false

    return config
  },
  error => {
    return Promise.reject(error)
  },
)

export { api }

