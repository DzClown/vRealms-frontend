<template>
  <v-container>
    <h1>Dashboard</h1>
  </v-container>
</template>
