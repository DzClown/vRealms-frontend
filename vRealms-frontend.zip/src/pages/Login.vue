<template>
  <v-container class="fill-height d-flex justify-center align-center">
    <v-card width="400">
      <v-card-title>Login</v-card-title>
      <v-card-text>
        <v-form v-model="valid" ref="form">
          <v-text-field
            v-model="username"
            label="Username"
            required
          ></v-text-field>
          <v-text-field
            v-model="password"
            label="Password"
            type="password"
            required
          ></v-text-field>
        </v-form>
      </v-card-text>
      <v-card-actions>
        <v-btn :disabled="!valid" @click="login">Login</v-btn>
      </v-card-actions>
    </v-card>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      username: '',
      password: '',
      valid: false,
    };
  },
  methods: {
    async login() {
      try {
        const response = await axios.post(
          'https://api-service.vrealmscity.com:26920/api/v1/auth/login',
          { username: this.username, password: this.password }
        );
        localStorage.setItem('accessToken', response.data.dataLogin.accessToken);
        this.$router.push({ name: 'Dashboard' });
      } catch (error) {
        console.error('Login failed:', error.response?.data || error.message);
        alert('Login gagal. Periksa username atau password.');
      }
    },
  },
};
</script>
