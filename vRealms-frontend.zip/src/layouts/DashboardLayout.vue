<template>
  <v-app>
    <v-navigation-drawer app>
      <Sidebar />
    </v-navigation-drawer>
    <v-app-bar app>
      <Navbar />
    </v-app-bar>
    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
import Navbar from '../components/Navbar.vue';
import Sidebar from '../components/Sidebar.vue';

export default {
  components: { Navbar, Sidebar },
};
</script>
